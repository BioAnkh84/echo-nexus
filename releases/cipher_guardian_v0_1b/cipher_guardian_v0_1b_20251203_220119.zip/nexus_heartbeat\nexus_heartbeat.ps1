[CmdletBinding()]
param(
    [string]$RootPath = 'E:\Echo_Nexus_Data'
)

$ErrorActionPreference = 'Stop'

$logsDir = Join-Path $RootPath 'logs'
if (-not (Test-Path $logsDir)) {
    New-Item -ItemType Directory -Path $logsDir -Force | Out-Null
}

$heartbeatPath = Join-Path $logsDir 'heartbeat.jsonl'

$ts = (Get-Date).ToUniversalTime().ToString('o')

# CPU %
$cpuSample = (Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples.CookedValue

# Memory (MB)
$os = Get-CimInstance Win32_OperatingSystem
$freeMB  = [math]::Round($os.FreePhysicalMemory / 1024, 2)
$totalMB = [math]::Round($os.TotalVisibleMemorySize / 1024, 2)

# Nexus data drive
try {
    $drive = Get-Volume -DriveLetter 'E'
    $freeGB  = [math]::Round($drive.SizeRemaining / 1GB, 2)
    $totalGB = [math]::Round($drive.Size / 1GB, 2)
}
catch {
    $freeGB  = $null
    $totalGB = $null
}

$entry = [ordered]@{
    ts_utc         = $ts
    host           = $env:COMPUTERNAME
    cpu_percent    = [math]::Round($cpuSample, 2)
    mem_free_mb    = $freeMB
    mem_total_mb   = $totalMB
    drive_letter   = 'E'
    drive_free_gb  = $freeGB
    drive_total_gb = $totalGB
}

$entry | ConvertTo-Json -Depth 4 -Compress | Add-Content -Path $heartbeatPath
