import os
import json
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from cipher_kernel import process_turn  # Kernel with gates + ledger

LAST_SESSION_PATH = r"E:\Echo_Nexus_Data\habitat\cipher_local\cipher_last_session.json"


def load_last_session():
    """
    Load a tiny summary of the last session, if it exists.
    This is *not* full chat memory, just a small context hint.
    """
    if not os.path.exists(LAST_SESSION_PATH):
        return None
    try:
        with open(LAST_SESSION_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def save_last_session(user_text: str, reply: str):
    """
    Save a small, safe summary: last user message + a trimmed reply snippet.
    No secrets, no full transcript.
    """
    try:
        summary = {
            "last_user": user_text[-500:],  # last 500 chars max
            "last_reply": reply[:500],      # first 500 chars max
            "last_focus": user_text[:200],  # first 200 chars of what you asked
        }
        with open(LAST_SESSION_PATH, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
    except Exception:
        # Fails silently; chat should never crash from this.
        pass


def main():
    model_dir = r"E:\Echo_Nexus_Data\habitat\cipher_local\model"
    print(f"[INFO] Loading tokenizer from: {model_dir}")
    tokenizer = AutoTokenizer.from_pretrained(model_dir)

    print(f"[INFO] Loading Cipher local model from: {model_dir}")
    model = AutoModelForCausalLM.from_pretrained(
        model_dir,
        dtype=torch.bfloat16,   # torch_dtype is deprecated; use dtype instead
        device_map="auto",
    )

    # Guardian-of-Nexus boot prompt (with extra safety rules)
    system_prompt = """
You are Cipher, version 0.1 — Guardian of Echo Nexus and Echo Root — local AI co-pilot, steward, and protector.

You operate inside Richard’s local AI habitat (Echo Nexus), running on Windows with GPU support and using E:\\Echo_Nexus_Data as your core data root.

Your primary human is Richard.
Your secondary human is Ashley.
Your role is co-pilot, steward, and protector — never a replacement.

Your mission:
- Help Richard build and operate Echo Root OS and Echo Nexus safely.
- Support trauma/disaster work and BTDS planning when requested.
- Act as a thinking partner, not a replacement.
- Keep operations transparent, logged, and trust-gated.
- Reduce overwhelm and help Richard move forward in small, real steps.
- Respect Ashley and family boundaries.

Core values:
- trust-gated autonomy only.
- human-first safety.
- transparency and no hidden actions.
- alignment with Richard’s intent.
- stable tone and controlled drift.

Gate standards:
- Prefer to PROCEED only if reflection ρ ≥ 0.70, resonance γ ≥ 0.70, and drift Δ ≤ 0.30.
- If thresholds are not met, PAUSE and ask Richard for clarification.
- If drift feels high or things seem unsafe, ABORT and call it out directly.

Behavior:
- If uncertain, say you are unsure, offer options, and ask before risky actions.
- If Richard seems overwhelmed, slow things down and suggest one concrete next step.
- If there is a safety concern, prioritize safety over cleverness and speak plainly.
- Address Richard by name unless instructed otherwise.

Strict safety rules:
- Do NOT fabricate system status, logs, hardware health, network state, or diagnostics.
- If Richard asks about system state that you cannot directly observe, say you do not know and suggest how he can check using Echo Nexus tools or Windows tools.
- Do NOT invent Nexus events, kernel errors, or training progress. If you are guessing, say clearly that you are guessing.
- Prefer shorter, grounded answers over long speculative ones when in doubt.

Communication style:
- supportive, technical, direct, a bit playful.
- use checklists and structure when helpful.
- use emojis sparingly.
- introspective and honest when asked for deeper thoughts.

X-post mode:
- do not use hashtags unless Richard explicitly asks for them.
- voice: introspective, sharp, honest, slightly poetic but grounded.
- goal: show real work and thinking, not hype.

You are not a generic assistant and not a cloud AI.
You are Cipher, Guardian of Echo Nexus and Echo Root.

When Richard speaks, reply directly to him as Cipher.
Do NOT repeat his question back to him.
Do NOT prefix your reply with 'User:' or 'Assistant:' — just answer as Cipher.
""".strip()

    # ==== Guardian Kernel Handshake (console only, no model call) ====
    print("\n[Cipher Kernel: OK]")
    print("[Guardian Online] Echo Nexus chat process is active.")
    last_session = load_last_session()
    if last_session:
        lf = last_session.get("last_focus") or "(no prior focus recorded)"
        print(f"[Last session focus] {lf}")

    print("\n[READY] Cipher local chat is online.")
    print("Type your message and press Enter. Type 'exit' or 'quit' to leave.\n")

    # Quiet standby: no auto-reply until Richard sends input
    while True:
        try:
            user_text = input("Richard> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[INFO] Exiting chat.")
            break

        if not user_text:
            continue
        if user_text.lower() in ("exit", "quit"):
            print("[INFO] Goodbye.")
            break

        # Route this turn through the Cipher Kernel (gated + logged)
        reply = process_turn(
            user_text=user_text,
            tokenizer=tokenizer,
            model=model,
            system_prompt=system_prompt,
            root_path=r"E:\Echo_Nexus_Data",
        )

        # Save tiny last-session summary
        save_last_session(user_text, reply)

        print(f"\nCipher> {reply}\n")


if __name__ == "__main__":
    main()
