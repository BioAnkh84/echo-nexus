# ================================================
# Echo Nexus — Unified Launcher
# ================================================
$root    = "E:\Echo_Nexus_Data"
$habitat = "$root\habitat\cipher_local"

Write-Host "=== Echo Nexus Launcher ===" -ForegroundColor Cyan
Write-Host "Root: $root" -ForegroundColor DarkGray

# ------------------------------------------------
# 1) Optional: Start Nexus heartbeat service
#    (uses your existing nexus_heartbeat.ps1 if present)
# ------------------------------------------------
$heartbeat = "$root\nexus_heartbeat\nexus_heartbeat.ps1"
if (Test-Path $heartbeat) {
    Write-Host "[Heartbeat] Starting nexus_heartbeat.ps1..." -ForegroundColor Yellow
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$heartbeat`""
} else {
    Write-Host "[Heartbeat] Script not found at $heartbeat" -ForegroundColor DarkYellow
}

# ------------------------------------------------
# 2) Start Cipher local chat in its own window
# ------------------------------------------------
$chat = "$habitat\cipher_local_chat.py"
if (Test-Path $chat) {
    Write-Host "[Cipher] Starting local chat..." -ForegroundColor Yellow

    $cmd = @"
cd `"$habitat`"
`$Host.UI.RawUI.WindowTitle = 'Cipher - Guardian of Echo Nexus'
python .\cipher_local_chat.py
"@

    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command $cmd"
} else {
    Write-Host "[Cipher] Chat script not found at $chat" -ForegroundColor Red
}

Write-Host "`n=== Echo Nexus Online (launcher complete) ===" -ForegroundColor Green
