# Launch Local Cipher Chat with kernel

cd "E:\Echo_Nexus_Data\habitat\cipher_local"

# Set window title (ASCII-safe)
$Host.UI.RawUI.WindowTitle = "Cipher - Guardian of Echo Nexus"

# Start the local Cipher chat
python "E:\Echo_Nexus_Data\habitat\cipher_local\cipher_local_chat.py"
