import json
from cipher_sensors import get_summary, ROOT_DEFAULT


def main():
    root = ROOT_DEFAULT
    summary = get_summary(root)

    print("[Cipher Sensors] Echo Nexus habitat summary")
    print(f"Root path: {summary.get('root_path')}")
    print("")

    drive = summary.get("drive", {})
    print("[Drive]")
    print(f"  Path:      {drive.get('path')}")
    print(f"  OK:        {drive.get('ok')}")
    print(f"  Total GB:  {drive.get('total_gb')}")
    print(f"  Used GB:   {drive.get('used_gb')}")
    print(f"  Free GB:   {drive.get('free_gb')}")
    if drive.get("note"):
        print(f"  Note:      {drive.get('note')}")
    print("")

    gpu = summary.get("gpu", {})
    print("[GPU]")
    print(f"  torch.cuda available: {gpu.get('torch_cuda_available')}")
    print(f"  torch device count:   {gpu.get('torch_device_count')}")
    print(f"  nvidia-smi found:     {gpu.get('nvidia_smi_found')}")
    if gpu.get("nvidia_gpus"):
        print("  GPUs:")
        for g in gpu["nvidia_gpus"]:
            line = f"    - {g.get('name')}"
            if "mem_total_mb" in g:
                line += f" ({g.get('mem_total_mb')} MB total"
                if "mem_used_mb" in g:
                    line += f", {g.get('mem_used_mb')} MB used"
                line += ")"
            print(line)
    if gpu.get("note"):
        print(f"  Note:      {gpu.get('note')}")
    print("")

    hb = summary.get("heartbeat", {})
    print("[Heartbeat]")
    print(f"  Path:      {hb.get('path')}")
    print(f"  Available: {hb.get('available')}")
    if hb.get("last_event"):
        print("  Last event:")
        for k, v in hb["last_event"].items():
            print(f"    {k}: {v}")
    if hb.get("note"):
        print(f"  Note:      {hb.get('note')}")
    print("")

    ckpt = summary.get("checkpoints", {})
    print("[Training Checkpoints]")
    print(f"  Root:              {ckpt.get('root')}")
    print(f"  OK:                {ckpt.get('ok')}")
    print(f"  Checkpoint files:  {ckpt.get('checkpoint_files')}")
    print(f"  Latest checkpoint: {ckpt.get('latest_checkpoint')}")
    if ckpt.get("note"):
        print(f"  Note:              {ckpt.get('note')}")
    print("")

    # Raw JSON at the end if you want it
    print("[Raw JSON]")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
