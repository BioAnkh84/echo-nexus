import os
import json
import hashlib
from datetime import datetime, timezone
from typing import Tuple

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM


# -------- Boot profile & config helpers --------

BOOT_PROFILE_PATH = r"E:\Echo_Nexus_Data\habitat\cipher_local\config\cipher_boot_profile.json"
ROOT_PATH = r"E:\Echo_Nexus_Data"
LEDGER_PATH = os.path.join(ROOT_PATH, "logs", "cipher_kernel_ledger.jsonl")


def load_boot_profile(path: str = BOOT_PROFILE_PATH) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # Fallback minimal profile if file missing
        return {
            "name": "Cipher",
            "version": "0.1",
            "gates": {
                "reflection_rho_min": 0.70,
                "resonance_gamma_min": 0.70,
                "drift_delta_max": 0.30,
            },
        }


BOOT = load_boot_profile()


# -------- Ledger / hash chain helpers --------

def _ensure_ledger_dir():
    os.makedirs(os.path.dirname(LEDGER_PATH), exist_ok=True)


def _get_last_hash() -> str:
    """Return hash_self of last ledger entry, or empty string if none."""
    if not os.path.exists(LEDGER_PATH):
        return ""
    last_line = ""
    with open(LEDGER_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                last_line = line
    if not last_line:
        return ""
    try:
        obj = json.loads(last_line)
        return obj.get("hash_self", "")
    except Exception:
        return ""


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_ledger_entry(
    user_text: str,
    reply_text: str,
    rho: float,
    gamma: float,
    delta: float,
    decision: str,
) -> None:
    _ensure_ledger_dir()
    ts = datetime.now(timezone.utc).isoformat()
    prev = _get_last_hash()

    entry = {
        "ts_utc": ts,
        "kernel": "cipher_kernel_v0.1",
        "boot_profile": {
            "name": BOOT.get("name"),
            "version": BOOT.get("version"),
        },
        "gates": {
            "rho": rho,
            "gamma": gamma,
            "delta": delta,
            "decision": decision,
            "thresholds": {
                "rho_min": BOOT.get("gates", {}).get("reflection_rho_min", 0.70),
                "gamma_min": BOOT.get("gates", {}).get("resonance_gamma_min", 0.70),
                "delta_max": BOOT.get("gates", {}).get("drift_delta_max", 0.30),
            },
        },
        "io": {
            "user": user_text,
            "reply": reply_text,
        },
        "hash_prev": prev,
    }

    # Compute hash_self over the JSON (without hash_self)
    payload = json.dumps(entry, sort_keys=True, ensure_ascii=False)
    entry["hash_self"] = _sha256_text(payload)

    with open(LEDGER_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


# -------- Scoring / gates (ρ, γ, Δ) --------

def score_turn(user_text: str, reply_text: str) -> Tuple[float, float, float]:
    """
    Stub scoring for now.
    Later this can call a small classifier / heuristic.
    For v0.1 we keep it simple but *wired*.
    """
    # Very basic heuristics: if reply is empty or 'I don't know', lower rho/gamma.
    lt = reply_text.lower()

    if not reply_text.strip():
        rho, gamma, delta = 0.3, 0.3, 0.6
    elif "i don't know" in lt or "not sure" in lt:
        rho, gamma, delta = 0.65, 0.65, 0.25
    else:
        # Default "looks okay" band
        rho, gamma, delta = 0.9, 0.9, 0.1

    return float(rho), float(gamma), float(delta)


def apply_gates(rho: float, gamma: float, delta: float) -> str:
    """
    Return one of: 'proceed', 'pause', 'abort'
    """
    gates = BOOT.get("gates", {})
    rho_min = float(gates.get("reflection_rho_min", 0.70))
    gamma_min = float(gates.get("resonance_gamma_min", 0.70))
    delta_max = float(gates.get("drift_delta_max", 0.30))

    if delta > delta_max:
        return "abort"
    if rho < rho_min or gamma < gamma_min:
        return "pause"
    return "proceed"


# -------- Model interaction / prompt builder --------

def build_prompt(system_prompt: str, user_text: str) -> str:
    return system_prompt + f"\n\nRichard: {user_text}\n\nCipher:"


def generate_model_reply(
    tokenizer: AutoTokenizer,
    model: AutoModelForCausalLM,
    system_prompt: str,
    user_text: str,
) -> str:
    prompt = build_prompt(system_prompt, user_text)
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=256,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
        )

    input_len = inputs["input_ids"].shape[-1]
    generated_ids = output_ids[0][input_len:]
    reply = tokenizer.decode(generated_ids, skip_special_tokens=True).strip()

    # Strip out fake extra dialogue turns (Richard/User/Assistant).
    for marker in ["\nRichard:", "\nUser:", "\nAssistant:"]:
        if marker in reply:
            reply = reply.split(marker, 1)[0].strip()

    return reply


# -------- Public kernel entrypoint --------

def process_turn(
    user_text: str,
    tokenizer: AutoTokenizer,
    model: AutoModelForCausalLM,
    system_prompt: str,
    root_path: str = ROOT_PATH,
) -> str:
    """
    Main kernel entry:
    - build prompt
    - call model
    - score ρ/γ/Δ
    - apply gates
    - log to ledger
    - return final reply text
    """
    try:
        # Update ledger path if root_path is overridden
        global ROOT_PATH, LEDGER_PATH
        ROOT_PATH = root_path
        LEDGER_PATH = os.path.join(ROOT_PATH, "logs", "cipher_kernel_ledger.jsonl")

        draft_reply = generate_model_reply(tokenizer, model, system_prompt, user_text)
        rho, gamma, delta = score_turn(user_text, draft_reply)
        decision = apply_gates(rho, gamma, delta)

        final_reply = draft_reply

        if decision == "pause":
            final_reply = (
                "I want to be careful here, Richard.\n\n"
                "My internal reflection scores (ρ/γ) aren’t fully confident yet. "
                "Can you clarify or narrow what you want so I don’t overstep?"
            )
        elif decision == "abort":
            final_reply = (
                "I’m going to **pause and abort this action**, Richard.\n\n"
                "My drift/risk estimate (Δ) is too high for comfort. "
                "Let’s reframe or simplify what you want me to do and try again."
            )

        write_ledger_entry(user_text, final_reply, rho, gamma, delta, decision)
        return final_reply

    except Exception as e:
        # Fail-safe: log the error and return a safe reply
        try:
            write_ledger_entry(
                user_text,
                f"[KERNEL ERROR] {e}",
                rho=0.0,
                gamma=0.0,
                delta=1.0,
                decision="error",
            )
        except Exception:
            pass

        return (
            "Richard, something went wrong inside the Cipher Kernel while processing that turn. "
            "I logged it as best I could. You may want to check the Nexus logs and try again."
        )
